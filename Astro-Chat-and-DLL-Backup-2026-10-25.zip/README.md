# Astro chat and DLL backup

Created 2026-10-25T04:19:18.436353+00:00.

- chat/Chat.md: readable transcript of all 36 messages returned by the stored-conversation export, without pagination or message truncation.
- chat/chat-history.json: original structured message export.
- dll/: latest delivered DLL v0.12.0, installation/change notes, and original verification report.
- SHA256SUMS.txt: checksums for every other archive member.

This backup contains conversation text. Attachment files, linked videos, tool logs, source code, signing keys, and external downloads are not embedded. The empty user message is retained as returned by the export. The backup ends at the assistant's initial backup progress message; subsequent packaging messages are not included.

## Current work status

The DLL targets the Windows BepInEx environment; it cannot run unchanged on Quest. Latest companion APK is v0.12.1, which exports game files and stores DLLs but does not implement injection. The Quest port/loader is unfinished. User reports Gorilla Tag 1.1.149 / code30699 on Quest2; the actual game APK is still unavailable for inspection. Gofile link https://gofile.io/d/3DFXlOK1 returned premium-access and rate-limit errors. Video previews identified ByteUs and ByteZuku; full YouTube playback was blocked.

Outstanding DLL limitations are documented in the included release notes: native game/VR testing, camera-only voice muting, and exact reference shader/animation matching. No new build was made for this backup.

To verify after extraction: run `sha256sum -c SHA256SUMS.txt` from the extracted folder (or compare SHA256 values with your preferred checksum tool).
