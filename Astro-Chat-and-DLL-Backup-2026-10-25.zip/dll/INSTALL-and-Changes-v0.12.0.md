# Astro's Infinity Tablet v0.12.0

## Install

Close Gorilla Tag. Put **one** copy of `AstrosInfinityTablet.dll` in `Gorilla Tag/BepInEx/plugins/`, replacing the previous Astro tablet DLL. Remove duplicate Astro versions. Keep your BepInEx installation and config. This build targets Windows Steam/Mono with BepInEx 5 and .NET Framework 4.7.2; no game assemblies are bundled.

## Changes

- **Digital watch:** rectangular themed case, strap, accent trim and A / INFINITY mark, with the computer's real local time, weekday and date. Tap with the left fingertip to open/close the watch wheel. The watch follows the rendered right-hand skeleton in world coordinates, avoiding inherited bone scale or disabled parents. It uses a wearer-facing wrist pose and a constant physical size. If the skin exposes no right-hand bone, the existing palm/controller fallback is used. Actual fit requires headset testing.
- **Opening:** the wheel scales and rotates into place over 0.32 seconds, with a soft three-note chord. Input becomes active after the opening completes. This is an original animation: the requested new video was not attached, so exact video matching remains outstanding.
- **Calibration migration:** wrist offsets/rotation from the old bone-local frame reset **once** to the new frame. Theme, size, wheel settings and shortcuts are preserved. Watch > Customize still offers offsets/rotation for avatar-specific adjustment. Reset Fit resets the new frame.
- **Pointer:** endpoint diameter increases from 22 to 32 mm at its base scale. The black ring surrounds the endpoint only while the trigger is held. The black beam and username shadow strokes are removed. Trigger presses on active pointers play a click sound, including selection away from buttons. Duplicate same-frame button/pointer sounds are suppressed.
- **Header:** bold two-line ASTROS INFINITY TABLET centered between cloud and speaker controls at their height. Custom titles are retained. The speaker outline with three waves follows the supplied reference icon and uses your theme.
- **Player card:** MSG becomes Mute All. It mutes everyone except the selected player, including new arrivals while active, and temporarily unmutes that player if needed. Press again to restore owned changes. Preexisting mutes and subsequent external changes are preserved. If the selected identity leaves, surviving players' owned changes restore. Focus is not persisted across sessions. The existing global lobby mute remains on the main tablet. Player card RGB, ID, Seen and actor diagnostics are hidden; public status/report text now says leaderboard.
- **Microphone:** Open/PTT/PTM select Gorilla Tag's native `GorillaComputer.pttType` modes, matching the inspected reference's mode-setting path. Native game controls handle press/release, without competing per-frame Recorder writes. Astro config saves the selected mode; the plugin does not overwrite the game's saved PlayerPrefs. Disabling restores the native value if still owned. Mute Self keeps its working recorder path. The prior Y-input fallback remains for builds without the native API; native availability and real input need game verification.
- **Local visual controls:** existing watch tint/brightness/fog/light/sky controls now tint existing renderer and material-slot color property overrides, which otherwise take precedence over copied material colors. Dynamic game colors are retinted without compounding, alpha and unrelated block properties are preserved, and owned colors restore on disable. New scene material replacements are rescanned. Original shader/texture assets are kept. Wardrobe code and owned cosmetic application are retained from v0.11.

## Outstanding requests

**Exact reference shader controls:** the inspected Sakuraa core and SakMerge assemblies expose native world time/weather and UI shader materials, but no matching global shader-settings page. This release repairs Astro's local tint implementation; its Cinematic/Dream/custom settings do not claim to be a copy of an unseen reference page. The latest message supplied six images, with no picture 7. Send that shader settings image and identify which reference DLL/page you want matched.

**Camera-only lobby voice mute:** the plugin currently produces a spectator image and PNG photos. It has no separate captured audio track, recorder or stream mixer to mute. The camera's old Mute All button incorrectly invoked the headset's global lobby mute; that connection is removed. Camera Audio now describes the missing recording route instead of presenting a false mute toggle. A camera-only voice mix remains unimplemented. Specify your recording target (recorded video/stream, OBS desktop capture, or a separate audio device) so the output can be designed correctly. No headset AudioSource/leaderboard muting is used as a substitute.

**Exact watch opening:** attach the intended video. The earlier YouTube short could not be viewed in this environment.

## Verification and limits

Build uses SDK 9.0.319, pinned public Unity 2021.3.33 / BepInEx 5.4.20 compile references. Automated checks cover data/identity, reports/mute, wardrobe, world time/weather and lobby policies, synthetic camera rendering-state restoration, native/fallback microphone ownership, focus mute, calibration/reveal, layout and material/property-block/light/sky/fog restoration. Static inspection checks version, parsable IL and PNG-only embedded resources. Exact results accompany the DLL.

No Gorilla Tag game, native Unity player/GPU, Windows/SteamVR or headset is installed here. Successful compilation and synthetic tests do not establish actual wrist fit, game input compatibility, graphics appearance, multiplayer behavior or recording audio.

### In-game check list

1. Confirm the watch appears at the right wrist through avatar movement/scaling. Check real time/date, tap, opening sound and Customize offsets. Verify profile/wardrobe still works.
2. Check pointer diameter, ring only while pressed, no black beam, and one audible click per trigger press.
3. Check title/icon placement and player card. Pre-mute a friend, activate Mute All on another player, join a new friend, then turn it off and confirm prior mutes restore. Check identity departure clears focus.
4. Test native Open/PTT/PTM on press/release, then Mute Self. Disable the plugin and verify the game's previous mic mode is restored.
5. Enable a strong custom visual tint on the watch, adjust brightness/fog, then disable. Check map surfaces using property overrides and restoration after time/map changes; monitor frame time.
6. Confirm Camera Audio never changes headset voice mutes. Separate recording audio remains an outstanding feature.

For game-specific failures, send screenshots and the relevant `BepInEx/LogOutput.log` entries.
